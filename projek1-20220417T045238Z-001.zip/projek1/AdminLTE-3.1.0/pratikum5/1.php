<?php
for ($x = 1; $x < 10; $x++) {
    echo $x." ";
  }
?>